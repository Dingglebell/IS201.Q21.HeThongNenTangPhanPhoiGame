# Arcadia - Hệ thống quản lý nền tảng phân phối game

Ứng dụng desktop JavaFX + Maven + Oracle 21c phục vụ demo đồ án. Code bám theo hai tài liệu thiết kế:

- `PTTKHTTT_Main.docx`: nghiệp vụ, use case, vai trò người dùng.
- `HQTCSDL_Main.docx`: mô hình dữ liệu quan hệ, ràng buộc và trigger.

## Công nghệ

- Java 21 trở lên
- JavaFX 21
- Maven
- Oracle Database 21c Enterprise/Standard hoặc Oracle XE tương thích JDBC
- Oracle JDBC `ojdbc11`

## Cấu trúc chính

```text
src/main/java/com/gameplatform/
  App.java
  config/       Đọc cấu hình DB
  controller/   Controller nghiệp vụ theo sequence, trực tiếp gọi JDBC/SQL
  database/     Tạo kết nối JDBC
  model/        Entity/DTO, enum LoaiTaiKhoan và VaiTroNhanVien
  service/      Lớp phụ trợ: exception xác thực, hash mật khẩu
  ui/           JavaFX UI theo vai trò
src/main/resources/
  db.properties
  css/app.css
sql/
  00_tao_user_game_platform.sql
  01_tao_cau_truc_csdl.sql
  02_nap_du_lieu_mau.sql
  
  99_cai_dat_day_du.sql
```

## Thiết lập Oracle

Kết nối mặc định đang để:

```properties
db.url=jdbc:oracle:thin:@localhost:1521/orclpdb
db.username=GAME_PLATFORM
db.password=game123
```

Nếu Oracle của bạn khác service name hoặc port, sửa `src/main/resources/db.properties`, hoặc đặt biến môi trường:

```powershell
$env:GAME_DB_URL="jdbc:oracle:thin:@localhost:1521/orclpdb"
$env:GAME_DB_USERNAME="GAME_PLATFORM"
$env:GAME_DB_PASSWORD="game123"
```

Chạy SQL:

```sql
-- Cách nhanh, chạy bằng SYS/SYSTEM:
-- PowerShell nên đặt NLS_LANG để SQL*Plus đọc tiếng Việt UTF-8 đúng:
-- $env:NLS_LANG='.AL32UTF8'
@sql/99_cai_dat_day_du.sql

-- Hoặc chạy thủ công:
-- Bằng SYS/SYSTEM nếu cần tạo user
@sql/00_tao_user_game_platform.sql

-- Bằng user GAME_PLATFORM
@sql/01_tao_cau_truc_csdl.sql
@sql/02_nap_du_lieu_mau.sql
```

## Chạy project

Cài Maven và mở thư mục này bằng VSCode, sau đó chạy:

```powershell
mvn javafx:run
```

Nếu `mvn` chưa có trong PATH nhưng máy có NetBeans, có thể chạy:

```powershell
.\scripts\run_app.ps1
```

Script này sẽ tự thử Maven trong PATH trước, sau đó thử Maven đi kèm NetBeans tại
`C:\Program Files\Apache NetBeans\java\maven\bin\mvn.cmd`.

## Tài khoản demo

Mật khẩu chung: `123456`

| Vai trò | Username |
|---|---|
| Người chơi | `player01`, `player02`, `player03` |
| Nhà phát triển | `dev01`, `dev02` |
| Nhân viên - Quản lý nền tảng | `manager01` |
| Nhân viên - Kiểm duyệt viên | `moderator01` |
| Nhân viên - Marketing | `marketing01` |
| Nhân viên - CSKH | `cskh01` |

## Phạm vi demo hiện tại

- Đăng nhập, đăng ký người chơi, đăng ký nhà phát triển, đổi mật khẩu.
- Điều hướng theo `TaiKhoan.LoaiTaiKhoan`.
- Nếu là `Nhân viên`, tiếp tục phân quyền theo `NhanVien.VaiTro`.
- Người chơi: xem cửa hàng, wishlist, giỏ hàng, thanh toán qua stored procedure, lịch sử giao dịch, thư viện, tải game demo, đánh giá/xóa đánh giá, tạo ticket.
- Nhà phát triển: xem/cập nhật game của mình, quản lý media, thêm phiên bản mới, gửi game/phiên bản mới để tạo `YeuCauPhatHanh`, xem/xuất báo cáo doanh thu NPT.
- Kiểm duyệt viên: duyệt/từ chối yêu cầu phát hành; quản lý thể loại, tra cứu media/phiên bản; trigger Oracle tự cập nhật trạng thái game.
- Marketing: tạo/cập nhật chương trình khuyến mãi, gắn game vào khuyến mãi, cập nhật mức giảm, quản lý mã giảm giá.
- CSKH: nhận xử lý và phản hồi ticket.
- Quản lý nền tảng: tra cứu người chơi, khóa/mở tài khoản, tra cứu nhà phát triển, cập nhật tỷ lệ chia sẻ doanh thu, tạo tài khoản nhân viên theo 4 vai trò trong thiết kế, xem kho game, xem/xuất báo cáo doanh thu nền tảng.
- Các màn hình chọn game/chương trình khuyến mãi dùng danh sách chọn thay vì bắt nhập mã thủ công.
- Database có đủ 6 trigger, 8 stored procedure và 6 stored function theo phần thiết kế CSDL.

## Ghi chú khi bảo vệ

Xem [tai_lieu/DoiChieu.md](tai_lieu/DoiChieu.md) để đối chiếu nhanh giữa code, bảng dữ liệu, ràng buộc, controller và use case trong tài liệu.

Xem thêm [tai_lieu/HuongDanDemo.md](tai_lieu/HuongDanDemo.md) để nắm luồng code và kịch bản demo giao diện.

